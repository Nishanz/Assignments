#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <string.h>
#include <stdlib.h>

int active(char** params);
int passive(char** params);
int process(char* cmd);
char* gen(char* addr,char* uname);
char* replace_str(char *str, char *orig, char *rep);
int callchild;

int parse(char* maincmd, char** cmd, char** params)
{       
    int i,j,nocmds=0,noparams=0;
    char* maincmd2;
    strcpy(maincmd2,maincmd);
    strcat(maincmd2,";");
    cmd[0]=maincmd2;
    for(i = 0;i < 100; i++)
    {
        cmd[i] = strsep(&maincmd, ";");
        //if(cmd[strlen(cmd)-1] == ' ')cmd[strlen(cmd)-1] = '\0';
        if(cmd[i] == NULL) break;       
        //printf("%s\n",cmd[i]);
    }
    nocmds=i-1;
    
    for(j = 0; j < nocmds; j++)
    {
        //printf("%s\n",cmd[j]);
        for(i = 0; i < 10; i++) 
        {
            params[i] = strsep(&cmd[j], " ");
            if(params[i] == NULL) break;
            //printf("%s\n",params[i]);
        }
        noparams=i-1;
    
        if(strcmp(params[i-1],"&")==0)
        {
            callchild=1;
            params[i-1]=NULL;
        }
        //printf("Bckround process ? %d\n",callchild);
        if(strcmp(params[0], "exit") == 0) 
            return 0;
        
        if(callchild==1)
            if(passive(params) == 0) 
                return 0;
            
        if(callchild==0)
            if(active(params) == 0)
                return 0;
                
    }
    return 1;
}

int main(void)
{
    struct utsname buffer;
    char maincmd[100 + 1];    
    errno = 0;
    int cmdCount = 0;
    if (uname(&buffer) != 0) 
    {
      perror("uname");
      exit(EXIT_FAILURE);
    }
    
    while(1)
    {
        char* usr = getenv("USER");
        char* finalcwd;
        char cwd[1024];
        int isover=1;
        
        callchild=0;
        if (getcwd(cwd, sizeof(cwd)) == NULL)perror("getcwd() error");
        
        //finalcwd = gen(cwd,usr);
        printf("%s@%s:%s# ", usr, buffer.nodename, cwd);

        // Read command from standard input, exit on Ctrl+D
        if(fgets(maincmd, sizeof(maincmd), stdin) == NULL) break;
        isover = process(maincmd);
        
        if(isover==0)
            break; 
    }

    return 0;
}

int process(char* maincmd)
{
    char* params[10 + 1];
    char* cmd[100 + 1];

    if(maincmd[strlen(maincmd)-1] == '\n')maincmd[strlen(maincmd)-1] = '\0';

    if(parse(maincmd, cmd, params)==0)return 0;
}



int passive(char** params)
{
    pid_t pid = fork();

    if (pid == -1) 
    {
        char* error = strerror(errno);
        printf("fork: %s\n", error);
        return 0;
    }
    else if (pid == 0) 
    {
        if(strcmp(params[0],"cd")!=0)
            execvp(params[0], params);
        else
            chdir(params[1]);  
        if(setpgid(0,0)==-1)return 0;
        
        char* error = strerror(errno);
        return 1;
    }
    else 
    {
        int childStatus;
        //waitpid(pid, &childStatus, 0);
        return 1;
    }
    
    return 1;
}

int active(char** params)
{
    pid_t pid = fork();
    int i;
    for(i = 0; i < 10; i++) 
        {
            
            if(params[i] == NULL) break;
            //printf("%s\n",params[i]);
        }
    if (pid == -1) 
    {
        char* error = strerror(errno);
        printf("fork: %s\n", error);
        return 0;
    }
    else if (pid == 0) 
    {
        if(strcmp(params[0],"cd")!=0)
            execvp(params[0], params);
        else
            chdir(params[1]);
        
        char* error = strerror(errno);
        //printf("ameya's shell: %s: %s\n", params[0], error);
        return 1;
    }
    else 
    {
        int childStatus;
        waitpid(pid, &childStatus, 0);
        return 1;
    }
    
    return 1;
}

char* replace_str(char *str, char *orig, char *rep)
{
    static char buffer[4096];
    char *p;

    if(!(p = strstr(str, orig)))
        return str;

    strncpy(buffer, str, p-str);
    buffer[p-str] = '\0';
    sprintf(buffer+(p-str), "%s%s", rep, p+strlen(orig));

    return buffer;
}

char* gen(char* addr,char* uname)
{
    char s[100];
    char* addr2;
    strcpy(s,"/home/");
    strcpy(addr2,addr);
    strcat(s,uname);
    addr2 = replace_str(addr2,s,"~");      
    return addr2;
}
