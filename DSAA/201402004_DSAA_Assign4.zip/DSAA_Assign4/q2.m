%%Computing DCT values for the cropped portion

im = imread('LAKE.TIF');

crop1 = imcrop(im,[420 45 7 7]);
crop2 = imcrop(im,[427 298 7 7]);
crop3 = imcrop(im,[30 230 7 7]);

% Observation: The bottom right corner has many zeros incorporated.
% We can efficiently do run-length coding on this.
im1 = myDCT_quantization(myDCT(double(crop1),create_mat_dct(8)),0,2);
im2 = myDCT_quantization(myDCT(double(crop2),create_mat_dct(8)),0,2);
im3 = myDCT_quantization(myDCT(double(crop3),create_mat_dct(8)),0,2);

croprev1 = myIDCT(myDCT_dequantization(im1,0,2),create_mat_dct(8));
croprev2 = myIDCT(myDCT_dequantization(im2,0,2),create_mat_dct(8));
croprev3 = myIDCT(myDCT_dequantization(im3,0,2),create_mat_dct(8));
