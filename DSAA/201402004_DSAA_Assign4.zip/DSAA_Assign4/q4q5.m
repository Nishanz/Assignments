clc;clear;
im = imread('LAKE.TIF');
tic;
for c = 1:10
figure;
subplot(1,2,1);
imshow(im,[]);
title('JPEG Compression: Left- Original Right- Compressed')    
imdct = myDCT_quantization(myDCT(double(im),create_mat_dct(8)),0,c);
imrev = myIDCT(myDCT_dequantization(imdct,0,c),create_mat_dct(8));
subplot(1,2,2);
imshow(imrev,[]);
dim = [.32 .105 .3 .8];
str = ['Compression factor:  ' num2str(c)];
annotation('textbox',dim,'String',str,'FitBoxToText','on');
disp(['RMSE for c = ' num2str(c) ' is: ' num2str(RMSE(imrev,im)) ' and Entropy is: ' num2str(my_entropy(imrev))])
end
toc;
tic;
RMSEMat = zeros(1,101);
Entropy = zeros(1,101);
for c = 1:0.1:11 
imdct = myDCT_quantization(myDCT(double(im),create_mat_dct(8)),0,c);
imrev = myIDCT(myDCT_dequantization(imdct,0,c),create_mat_dct(8));
RMSEMat(1,uint32((c-1)*10+1)) = RMSE(imrev,im);
Entropy(1,uint32((c-1)*10+1)) = my_entropy(imrev);
end
toc;
figure;
title('JPEG Compression: Entropy vs RMSE')    
plot(RMSEMat,Entropy);xlim([0 15]);ylim([0 0.02])
xlabel('RMSE');ylabel('Entropy');

disp('The highest perceptible value of c is: 4. Then, the image is distorted.');
