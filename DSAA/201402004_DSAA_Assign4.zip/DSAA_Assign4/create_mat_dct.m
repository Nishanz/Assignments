function [dctmat] = create_mat_dct(N)
r0=sqrt((1/N));
r1=sqrt((2/N));
dctmat = zeros(N,N);

for x=0:N-1
    for y=0:N-1
        if x~=0
            dctmat(x+1,y+1)=r1*cos((pi*(2*y+1)*x)/(2*N));
        else
            dctmat(x+1,y+1)=r0*cos((pi*(2*y+1)*x)/(2*N));
        end
    end
end

dctans = dctmtx(N);

%disp(single(dctans)==single(dctmat));
           