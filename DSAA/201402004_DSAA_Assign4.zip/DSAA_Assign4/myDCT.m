function [dctim] = myDCT(im,F)
im = bsxfun(@minus,im,128);
dct = @(block_struct) F * block_struct.data * F';
dctim = blockproc(im,[8 8],dct);

