function [dctquant] = myDCT_quantiation(dctim,Q,c)

if Q==0
Q =uint8([  16 11 10 16  24  40  51  61
            12 12 14 19  26  58  60  55
            14 13 16 24  40  57  69  56
            14 17 22 29  51  87  80  62
            18 22 37 56  68 109 103  77
            24 35 55 64  81 104 113  92
            49 64 78 87 103 121 120 101
            72 92 95 98 112 100 103 99]);
end  
% cstan = 50*c;
% if cstan<50
%     Q_quan = bsxfun(@times,double(Q),(double(100-cstan)/50));
% end
% 
% if cstan>=50
%     Q_quan = bsxfun(@times,double(Q),(50/double(cstan)));
% end

Q_quan = c*single(uint8(Q));
quantize = @(block_struct)bsxfun(@rdivide,double(block_struct.data),double(Q_quan));
dctquant = blockproc(dctim,[8 8],quantize);
dctquant = round(dctquant);
