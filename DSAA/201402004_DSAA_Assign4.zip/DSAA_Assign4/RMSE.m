function [RMSE] = RMSE(im1,im2)
RMSE = sqrt(mean(mean((single(im1) - single(im2)).^2)));  % Root Mean Squared Error