clc;clear;
im = imread('LAKE.TIF');
imdct = myDCT_quantization(myDCT(double(im),create_mat_dct(8)),0,2);
%imrev = myIDCT(myDCT_dequantization(imdct,0,2),create_mat_dct(8));