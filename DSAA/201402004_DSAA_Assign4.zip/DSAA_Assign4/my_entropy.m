function [entropy] = my_entropy(im)
p=imhist(im);
rows = find(p);
tot = sum(p);
p = p ./ tot;
entropy =  -sum((p(rows)).*log2(p(rows)));
