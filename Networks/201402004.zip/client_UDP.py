import socket
from socket import AF_INET,SOCK_DGRAM
import time
print 'Running'  #Shows that the program has started running properly
serverName= raw_input() 
clientSocket=socket.socket(AF_INET,SOCK_DGRAM)
clientSocket.settimeout(1)
sequence_number=1
while sequence_number<=10:
    message='Ping'
    start=time.time()
    clientSocket.sendto(message,(serverName,12000))
    try:
        message,address=clientSocket.recvfrom(1024)
        elapsed=(time.time()-start)
        print message + " " + str(sequence_number)
        print 'Round Trip time is:' + str(elapsed) + " seconds"
    except socket.timeout:
        print message + " " + str(sequence_number)
        print 'Request timed out'
    sequence_number+=1
    if sequence_number > 10:
       clientSocket.close()
